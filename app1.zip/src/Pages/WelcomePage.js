import React from "react";
import { Link } from "react-router-dom";
import Header from "../Component/Header";
import Sidebar from "../Component/Sidebar";
import Home from "../Component/Home";

const WelcomePage = () => {
  return (
    <div>
      <Header />
      <Sidebar />
      <Home />
      <p>
        Go back to <Link to="/login">Login</Link>
      </p>
    </div>
  );
};

export default WelcomePage;
