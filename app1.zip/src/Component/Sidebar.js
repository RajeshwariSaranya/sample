import React, { useState, useEffect } from "react";
import { Link } from "react-router-dom";
import {
  BsGrid1X2Fill,
  BsFillArchiveFill,
  BsFillGrid3X3GapFill,
  BsFillGearFill,
} from "react-icons/bs";

const Sidebar = ({ openSidebarToggle, OpenSidebar }) => {
  const [showProducts, setShowProducts] = useState(false);
  const [showThemes, setShowThemes] = useState(false);
  const [currentTheme, setCurrentTheme] = useState("Light");

  const handleProductClick = (e) => {
    e.preventDefault();
    setShowProducts((prev) => !prev);
  };

  const handleThemeClick = (e) => {
    e.preventDefault();
    setShowThemes((prev) => !prev);
  };

  const handleThemeChange = (theme) => {
    setCurrentTheme(theme);
    document.body.classList.toggle("dark-theme", theme === "Dark");
    document.body.classList.toggle("light-theme", theme === "Light");
  };

  useEffect(() => {
    document.body.classList.add(currentTheme === "Dark" ? "dark-theme" : "light-theme");
  }, [currentTheme]);

  return (
    <aside id="sidebar" className={openSidebarToggle ? "sidebar-responsive" : ""}>
      <div className="sidebar-title">
        <span className="icon close_icon" onClick={OpenSidebar}>X</span>
      </div>

      <ul className="sidebar-list">
        <li className="sidebar-list-item">
          <Link to="/">
            <BsGrid1X2Fill className="icon" /> Dashboard
          </Link>
        </li>

        <li className="sidebar-list-item">
          <button onClick={handleProductClick} aria-expanded={showProducts} className="sidebar-button">
            <BsFillArchiveFill className="icon" /> Products
          </button>
          {showProducts && (
            <ul className="nested-list">
              {["Tomato", "Diesel", "Gold"].map((product, index) => (
                <li key={index}>
                  <button onClick={() => console.log(`${product} clicked!`)}>
                    {`${index + 1}. ${product}`}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </li>

        <li className="sidebar-list-item">
          <button onClick={handleThemeClick} aria-expanded={showThemes} className="sidebar-button">
            <BsFillGrid3X3GapFill className="icon" /> Theme
          </button>
          {showThemes && (
            <ul className="nested-list">
              {["Light", "Dark"].map((theme, index) => (
                <li key={index}>
                  <button onClick={() => handleThemeChange(theme)}>
                    {`${index + 1}. ${theme}`}
                  </button>
                </li>
              ))}
            </ul>
          )}
        </li>

        <li className="sidebar-list-item">
          <Link to="/settings">
            <BsFillGearFill className="icon" /> Settings
          </Link>
        </li>
      </ul>
    </aside>
  );
};

export default Sidebar;
